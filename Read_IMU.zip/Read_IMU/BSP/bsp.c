#include "bsp.h"


// The LED displays the current operating status, which is invoked every 10 milliseconds, and the LED blinks every 200 milliseconds.  
void Bsp_Led_Show_State_Handle(void)
{
	static uint8_t led_count = 0;
	led_count++;
	if (led_count > 20)
	{
		led_count = 0;
//		LED_TOGGLE();
	}
}


// The peripheral device is initialized
void Bsp_Init(void)
{
	uint8_t res = 0;
	USART1_Init();
	res = ICM20948_init();
	if (res != 0)
	{
		printf("ICM20948 INIT ERROR\n");
		while(1);
	}
	AK09916_init();
	Beep_On_Time(50);
}



int state = 0;

// This function is called in a loop in main.c to avoid multiple modifications to the main.c file
void Bsp_Loop(void)
{
	static int press_count = 0;

	// Detect button down events
	if (Key1_State(KEY_MODE_ONE_TIME))
	{
		Beep_On_Time(50);
		press_count++;
		printf("press:%d\n", press_count);

		if (press_count % 2 == 1)
		{
			if (state == 0)
			{
				printf("IMU Data Printing Started\n");
			}
			state = 1;
		}
		else
		{
			if (state == 1)
			{
				printf("IMU Data Printing Stopped\n");
			}
			state = 0;
		}
	}

	ICM20948_Read_Data_Handle();
	Bsp_Led_Show_State_Handle();
	Beep_Timeout_Close_Handle();
	HAL_Delay(10);
}
